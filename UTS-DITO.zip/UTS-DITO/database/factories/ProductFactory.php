<?php

namespace Database\Factories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */
class ProductFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $categories = ['Oli', 'Bensin', 'Lampu'];
        $category = $this->faker->randomElement($categories);

        // Daftar merek Oli
        $oliBrands = [
            'Castrol', 'Shell', 'Pertamina', 'Top 1', 'Mobil 1',
            'Fuchs', 'Motul', 'Total', 'Repsol', 'Agip'
        ];

        // Daftar merek Bensin
        $bensinBrands = [
            'Pertamax', 'Pertalite', 'Premium', 'Shell Super', 'Total Performance 92',
            'Shell V-Power', 'BP 90', 'BP 92', 'BP 95', 'Total Racing 95'
        ];

        // Daftar merek Lampu
        $lampuBrands = [
            'Philips', 'Osram', 'Panasonic', 'Miyoko', 'Sylvania',
            'GE Lighting', 'Toshiba', 'Samsung', 'Sharp', 'LG'
        ];

        $name = $category == 'Oli'
            ? $this->faker->randomElement($oliBrands)
            : ($category == 'Bensin'
                ? $this->faker->randomElement($bensinBrands)
                : $this->faker->randomElement($lampuBrands));

        // Deskripsi khusus untuk setiap kategori
        $description = $category == 'Oli'
            ? 'Oli berkualitas tinggi untuk performa mesin terbaik.'
            : ($category == 'Bensin'
                ? 'Bensin dengan oktan tinggi untuk efisiensi bahan bakar dan performa kendaraan.'
                : 'Lampu dengan pencahayaan optimal dan tahan lama.');

        return [
            'name' => $name,
            'description' => $description,
            'price' => $this->faker->numberBetween(20000, 500000),
            'image' => $this->faker->imageUrl(640, 480, 'product', true),
            'category_id' => $category == 'Oli' ? 1 : ($category == 'Bensin' ? 2 : 3),
            'expired_at' => now()->addDays(365),
            'modified_by' => $this->faker->randomElement(['admin@gmail.com', 'maulana@gmail.com'])
        ];
    }
}